# All of the files here are
	format(.c)
	_______
	Syntax: Format [cpu|apu] [infile]
		; You shouldn't run this manually. Run by genmake automatically
		
	The other files are Makefile Sections.